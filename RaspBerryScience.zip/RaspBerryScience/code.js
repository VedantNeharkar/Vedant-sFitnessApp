      
      getTime(console.log("started"));
      console.log(getTime());
      
      onEvent("Screen1", "click", function( ) {
        setScreen("Welcome");
      });
      
      
      
      onEvent("button1", "click", function( ) {
      setScreen("Q");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button2", "click", function( ) {
      setScreen("T&C");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button3", "click", function( ) {
      setScreen("Welcome");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button4", "click", function( ) {
      setScreen("GradeC");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button5", "click", function( ) {
      setScreen("T&C");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    //onEvent("button6", "click", function( ) {
      
    //});
    //onEvent("button7", "click", function( ) {
      
    //});
    onEvent("button8", "click", function( ) {
      setScreen("1&2");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button9", "click", function( ) {
      setScreen("Welcome");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("checkbox1", "click", function( ) {
      setScreen("P&A");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    
    onEvent("button10", "click", function( ) {
      setScreen("Welcome");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button11", "click", function( ) {
      setScreen("diagra");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button12", "click", function( ) {
      setScreen("P&A");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button13", "click", function( ) {
      setScreen("more");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button14", "click", function( ) {
      setScreen("diagra");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button15", "click", function( ) {
      setScreen("brief");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button16", "click", function( ) {
      setScreen("more");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button17", "click", function( ) {
      setScreen("Animals");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button18", "click", function( ) {
      setScreen("Photo");
      playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button19", "click", function( ) {
      setScreen("Animals");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button20", "click", function( ) {
      setScreen("TypesOFA");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button21", "click", function( ) {
      setScreen("GradeC");
      playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button22", "click", function( ) {
      setScreen("brief");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button23", "click", function( ) {
      setScreen("Welcome");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button24", "click", function( ) {
      setScreen("Photo");
      playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button25", "click", function( ) {
      setScreen("RateUs");
        playSound("assets/category_app/app_interface_button_2.mp3");
        playSound("assets/category_achievements/peaceful_win_8.mp3");
      
    });
    onEvent("button26", "click", function( ) {
      setText("RateUs", "Sorry For the inconveniences caused!We will definately improve, For learning again reload the page again!");
        playSound("assets/category_app/app_interface_button_2.mp3");
        playSound("assets/category_alerts/playful_quirky_negative_game_cue_2.mp3");
      
    });
    onEvent("button27", "click", function( ) {
      setText("RateUs", "Owwww! We are very sorry that you were not ready to learn , For learning again reload the page again!");
      playSound("assets/category_app/app_interface_button_2.mp3");
      playSound("assets/category_alerts/playful_quirky_negative_game_cue_2.mp3");
    });
    onEvent("button28", "click", function( ) {
      setText("RateUs", "We will surely try to make our app better. For learning again reload the page again!");
      playSound("assets/category_app/app_interface_button_2.mp3");
      playSound("assets/category_alerts/playful_quirky_negative_game_cue_2.mp3");
      
    });
    onEvent("button29", "click", function( ) {
      setText("RateUs", "Thank You! For rating us! Your rate minds us a lot. For learning again reload the page again!");
        playSound("assets/category_app/app_interface_button_2.mp3");
        playSound("assets/category_achievements/melodic_win_1.mp3");
      
    });
    onEvent("button30", "click", function( ) {
      setText("RateUs","OH My Goodness , thank You for rating us! , for learning again reload the page again");
        playSound("assets/category_app/app_interface_button_2.mp3");
         playSound("assets/category_achievements/melodic_win_1.mp3");
      
    });
    onEvent("button31", "click", function( ) {
      setScreen("Welcome");
        playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button32", "click", function( ) {
      setScreen("TypesOFA");
      playSound("assets/category_app/app_interface_button_2.mp3");
    });
    onEvent("button33", "click", function( ) {
      setScreen("1&2");
    });
    
    //Wa
    onEvent("checkbox2", "click", function( ) {
       setScreen("Water");
     });
     
    onEvent("button34", "click", function( ) {
      setScreen("Newwater");
    });
    onEvent("button35", "click", function( ) {
      setScreen("Water");
    });
    onEvent("button36", "click", function( ) {
      setScreen("Process");
    });
    onEvent("button37", "click", function( ) {
      setScreen("RateUs");
    onEvent("button38", "click", function( ) {
      setScreen("Newwater");
    });
    });
    //assistance
    
        onEvent("image10", "click", function( ) {
          playSpeech("shoot systum - yah vo hissa hai jisme jamin ke upar ke hisse jaise tanaa , patta , fool ugte hai","female","हिन्दी");
        });
        
       onEvent("image11", "click", function( ) {
         playSpeech("speaker ke chitr pe hindi ke liye dabayie , aapko her note ke bajoo me speaker ka button dabana hai , hindi me sunn ne ke liye ","female","हिन्दी");
       });
       
        onEvent("image13", "click", function( ) {
          playSpeech("aage badhiye","female","हिन्दी");
        });
        
        onEvent("image14", "click", function( ) {
          playSpeech("नियम और शर्तें","female","हिन्दी");
        });
        
        onEvent("image15", "click", function( ) {
          playSpeech("yahaan, aap bahut aasaan tareeke se vigyaan kee sabase kathin avadhaaranaon ke baare mein jaanenge aur isase aapako chhote sabak milenge jo aapako jeevan bhar yaad rahenge.","female","हिन्दी");
        });
        
        onEvent("image16", "click", function( ) {
          playSpeech("raspberry vigyan","female","हिन्दी");
        });
   
        onEvent("image12", "click", function( ) {
          playSpeech("Ha maine padha aur mai sahamat hu","female","हिन्दी");
        });
    
        onEvent("image17", "click", function( ) {
          playSpeech("Nahi maine nahi padha , mujhe vaha pe leke jao","female","हिन्दी");
        });
        
        onEvent("image18", "click", function( ) {
          playSpeech("piche","female","हिन्दी");
        });
        
        onEvent("image19", "click", function( ) {
          playSpeech("यह एप्लिकेशन विज्ञान के किसी भी उल्लंघन के लिए जिम्मेदार नहीं है। यह तथ्य, सूचनाएँ विभिन्न स्रोतों स प्राप्त होती हैं।  हम आपको सबसे अच्छी जानकारी देने की कोशिश करते हैं और इसे सच पाते हैं।  यदि सूचना हमारे ऐप की झूठी होगी ,तो न ही इस ऐप का मालिक या निर्माता दोषी होगा। जी शुक्रिया। आशा है कि आप इस एप्लिकेशन को उपयोगी पाते हैं","male","हिन्दी");    
        });
        
        onEvent("image20", "click", function( ) {
          playSpeech("में eess se sahamat hu.","female","हिन्दी")   ;     
        });   
        
        onEvent("image21", "click", function( ) {
          playSpeech("kyaa aapne niyam or sharte padhe","male","हिन्दी");
        });
        
        onEvent("image23", "click", function( ) {
          playSpeech("krupaya aap kiss kaksha me ho vo bataye","female","हिन्दी");
        });
        
        onEvent("image28", "click", function( ) {
          playSpeech("kaksha 1-2","female","हिन्दी");
        });
        
        onEvent("image31", "click", function( ) {
          playSpeech("kaksha 6-9","female","हिन्दी");
        });
     
        onEvent("image30", "click", function( ) {
          playSpeech("kaksha 3-5","female","हिन्दी");
          
        });
          
        onEvent("image29", "click", function( ) {
            playSpeech("piche","female","हिन्दी");
        });
            
        onEvent("image35", "click", function( ) {
            playSpeech("namaskar aap kya sikhna chahate ho","female","हिन्दी");
        });
         
        onEvent("image36", "click", function( ) {
            playSpeech("पौधे और पशु","female","हिन्दी");
        });
        
        onEvent("image34", "click", function( ) {
            playSpeech("Paani","female","हिन्दी");
            
        });
        
        onEvent("image33", "click", function( ) {
          playSpeech("hamari dharti","female","हिन्दी");
        });
        
        onEvent("image32", "click", function( ) {
          playSpeech("Mera shareer ke ang","female","हिन्दी");   
        });
        
        onEvent("image37", "click", function( ) {
          playSpeech("Piche");
        });
        
        onEvent("image38", "click", function( ) {
          playSpeech("एक पौधे एक जीवित चीज है जो पृथ्वी में बढ़ता है और एक स्टेम, पत्ते, और जड़ें होती है। ... जब कोई व्यक्ति किसी विशेष प्रकार के पौधे या फसल के साथ भूमि करता है, तो वे वहां उगने के लिए पौधों, बीज, या युवा पेड़ों को भूमि में डालते हैं।","female","हिन्दी");
        });
        
        onEvent("image40", "click", function( ) {
          playSpeech("Piche","female","हिन्दी");
        });
        
        onEvent("image39", "click", function( ) {
          playSpeech("chitr","female","हिन्दी");
        });
        
        



























